Foodie PWA — included firebase-config.js matches discipline-app (paste your Firebase web app config).
