/**
 * Foodie AI — Firebase callable (Gemini + USDA server-side). Local unit math + meal diary.
 */
import { firebaseConfig } from "./firebase-config.js";
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.1/firebase-app.js";
import {
  getFunctions,
  httpsCallable,
  connectFunctionsEmulator
} from "https://www.gstatic.com/firebasejs/10.8.1/firebase-functions.js";

const FX_REGION = "us-central1";
const MAX_BYTES = 4 * 1024 * 1024;
const HISTORY_KEY = "mealHistory";
const MAX_ENTRIES = 20;

let currentAi = null;
let currentPer100g = null;
let currentUsdaLabel = "";
let currentFdcId = null;

if (!firebaseConfig.apiKey || String(firebaseConfig.apiKey).indexOf("REPLACE") !== -1) {
  const b = document.getElementById("configBanner");
  if (b) b.classList.add("show");
}

const app = initializeApp(firebaseConfig);
const functions = getFunctions(app, FX_REGION);

/** Local: `npm run local` → Vite preview :4173, Functions emulator :5001 */
const isLocalHost =
  typeof location !== "undefined" &&
  (location.hostname === "localhost" || location.hostname === "127.0.0.1");
if (isLocalHost) {
  connectFunctionsEmulator(functions, "127.0.0.1", 5001);
}

const imageInput = document.getElementById("imageInput");
const btnPick = document.getElementById("btnPick");
const preview = document.getElementById("preview");
const resultsDiv = document.getElementById("results");
const loadingDiv = document.getElementById("loading");
const loadingText = document.getElementById("loadingText");
const controlsDiv = document.getElementById("controls");
const unitSelect = document.getElementById("unitSelect");
const historyContainer = document.getElementById("historyContainer");

btnPick.addEventListener("click", () => imageInput.click());

document.addEventListener("DOMContentLoaded", displayHistory);

unitSelect.addEventListener("change", () => {
  if (unitSelect && currentAi && currentPer100g) {
    renderNutritionTable();
  }
});

imageInput.addEventListener("change", async (event) => {
  const file = event.target.files && event.target.files[0];
  if (!file) return;
  if (file.size > MAX_BYTES) {
    showError("Image is too large (max 4 MB).");
    return;
  }
  if (!file.type.startsWith("image/")) {
    showError("Please choose an image file.");
    return;
  }

  preview.src = URL.createObjectURL(file);
  preview.style.display = "block";
  controlsDiv.classList.remove("show");
  resultsDiv.classList.remove("show");

  const base64Image = await fileToBase64(file);
  const m = String(base64Image).match(/^data:([^;]+);base64,(.+)$/);
  if (!m) {
    showError("Could not read image.");
    return;
  }
  await analyzeFood(m[2], m[1], file);
});

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
  });
}

function createThumbnailDataUrl(file, maxW = 320) {
  return new Promise((resolve) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      URL.revokeObjectURL(url);
      let w = img.naturalWidth;
      let h = img.naturalHeight;
      if (w > maxW) {
        h = Math.round((h * maxW) / w);
        w = maxW;
      }
      const canvas = document.createElement("canvas");
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext("2d");
      if (!ctx) {
        resolve("");
        return;
      }
      ctx.drawImage(img, 0, 0, w, h);
      try {
        resolve(canvas.toDataURL("image/jpeg", 0.82));
      } catch {
        resolve("");
      }
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      resolve("");
    };
    img.src = url;
  });
}

function escapeHtml(s) {
  const d = document.createElement("div");
  d.textContent = s;
  return d.innerHTML;
}

function showError(msg) {
  resultsDiv.innerHTML = `<p class="foodie-error-plain">${escapeHtml(msg)}</p>`;
  resultsDiv.classList.add("show");
  loadingDiv.classList.remove("show");
}

function setLoading(show, text) {
  loadingDiv.classList.toggle("show", show);
  if (loadingText && text) loadingText.textContent = text;
}

async function analyzeFood(base64Data, mimeType, file) {
  resultsDiv.classList.remove("show");
  setLoading(true, "Analyzing image and fetching USDA data…");

  try {
    const fn = httpsCallable(functions, "recognizeFood");
    const res = await fn({ imageBase64: base64Data, mimeType });
    const d = res.data || {};

    if (!d.ai || !d.per100g) {
      showError("Unexpected response from server.");
      return;
    }

    currentAi = d.ai;
    currentPer100g = d.per100g;
    currentUsdaLabel = typeof d.usdaLabel === "string" ? d.usdaLabel : "";
    currentFdcId = d.fdcId != null ? d.fdcId : null;

    if (unitSelect) unitSelect.value = "g";
    controlsDiv.classList.add("show");
    renderNutritionTable();

    const thumb = await createThumbnailDataUrl(file);
    saveToHistory({
      dishName: currentAi.dish || "Meal",
      cuisine: currentAi.cuisine || "—",
      thumbDataUrl: thumb,
      ai: currentAi,
      per100g: currentPer100g,
      usdaLabel: currentUsdaLabel,
      fdcId: currentFdcId
    });
  } catch (e) {
    console.error(e);
    const code = e.code || "";
    const msg =
      e.message ||
      "Something went wrong. Ensure GEMINI_API_KEY and USDA_API_KEY are set on the Cloud Run service.";
    showError((code ? "[" + code + "] " : "") + msg);
  } finally {
    setLoading(false);
  }
}

function portionMultiplierGrams(ai) {
  const g = typeof ai.estimatedWeightGrams === "number" ? ai.estimatedWeightGrams : 200;
  return g / 100;
}

function formatWeight(ai, unit) {
  const g = typeof ai.estimatedWeightGrams === "number" ? ai.estimatedWeightGrams : 200;
  if (unit === "oz") {
    return { val: (g / 28.3495).toFixed(2), label: "oz" };
  }
  if (unit === "lb") {
    return { val: (g / 453.592).toFixed(2), label: "lbs" };
  }
  return { val: g.toFixed(0), label: "g" };
}

function renderNutritionTable() {
  if (!currentAi || !currentPer100g) return;

  const unit = unitSelect ? unitSelect.value : "g";
  const mult = portionMultiplierGrams(currentAi);
  const p = currentPer100g;
  const w = formatWeight(currentAi, unit);

  const desc = currentAi.description || "";
  const dish = currentAi.dish || currentAi.searchableName || "Food";
  const fdcNote =
    currentFdcId != null
      ? `FDC ID ${currentFdcId} · ${escapeHtml(currentUsdaLabel)}`
      : escapeHtml(currentUsdaLabel);

  const rows = [
    ["Energy (kcal)", p.energy, mult * p.energy],
    ["Protein (g)", p.protein, mult * p.protein],
    ["Total fat (g)", p.fat, mult * p.fat],
    ["Carbohydrate (g)", p.carbs, mult * p.carbs],
    ["Dietary fiber (g)", p.fiber, mult * p.fiber]
  ];

  let tableHtml = "";
  for (const [label, per100, portion] of rows) {
    tableHtml += `<tr>
      <td>${escapeHtml(label)}</td>
      <td>${Number(per100).toFixed(1)}</td>
      <td class="foodie-nut-portion"><strong>${Number(portion).toFixed(1)}</strong></td>
    </tr>`;
  }

  resultsDiv.innerHTML = `
    <div class="foodie-nutrition">
      <h3 class="foodie-nut-title">${escapeHtml(dish)}</h3>
      <p class="foodie-nut-desc"><em>${escapeHtml(desc)}</em></p>
      <p class="foodie-nut-portion-line">
        <strong>Estimated portion:</strong>
        <span class="foodie-nut-weight">${escapeHtml(w.val)} ${escapeHtml(w.label)}</span>
        <span class="foodie-nut-sub">(AI estimate · USDA nutrients per 100&nbsp;g)</span>
      </p>
      <table class="foodie-nut-table">
        <thead>
          <tr>
            <th>Nutrient</th>
            <th>Per 100&nbsp;g</th>
            <th>Your portion</th>
          </tr>
        </thead>
        <tbody>${tableHtml}</tbody>
      </table>
      <p class="foodie-nut-source">${fdcNote}</p>
      <p class="foodie-nut-disclaimer">Source: USDA FoodData Central. Values are database averages; your exact meal may differ.</p>
    </div>
  `;
  resultsDiv.classList.add("show");
}

function saveToHistory(entry) {
  let history = [];
  try {
    history = JSON.parse(localStorage.getItem(HISTORY_KEY)) || [];
  } catch {
    history = [];
  }
  const newEntry = {
    date: new Date().toLocaleString(),
    ...entry
  };
  history.unshift(newEntry);
  if (history.length > MAX_ENTRIES) history.length = MAX_ENTRIES;
  localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
  displayHistory();
}

function safeDataImageUrl(u) {
  if (typeof u !== "string" || !u.startsWith("data:image/")) return "";
  return u;
}

function displayHistory() {
  let history = [];
  try {
    history = JSON.parse(localStorage.getItem(HISTORY_KEY)) || [];
  } catch {
    history = [];
  }

  if (history.length === 0) {
    historyContainer.innerHTML =
      "<p class=\"foodie-history-empty\">No meals scanned yet. Snap a photo to start your diary.</p>";
    return;
  }

  historyContainer.innerHTML = history
    .map((item, index) => {
      const dish =
        typeof item.dishName === "string" && item.dishName
          ? item.dishName
          : item.details
            ? "Saved meal"
            : "Meal";
      const cuis = typeof item.cuisine === "string" && item.cuisine ? item.cuisine : "—";
      const dataUrl = safeDataImageUrl(item.thumbDataUrl);
      const thumb = dataUrl
        ? `<img class="history-thumb" src="${dataUrl.replace(/"/g, "&quot;")}" alt="" />`
        : `<div class="history-thumb history-thumb--placeholder" aria-hidden="true"><i class="fas fa-utensils"></i></div>`;
      return `
        <div class="history-item">
          ${thumb}
          <div class="history-body">
            <div class="history-date">🗓️ ${escapeHtml(item.date)}</div>
            <div class="history-dish">${escapeHtml(dish)}</div>
            <div class="history-cuisine">${escapeHtml(cuis)}</div>
            <button type="button" class="delete-btn" data-index="${index}">Delete</button>
          </div>
        </div>`;
    })
    .join("");

  historyContainer.querySelectorAll(".delete-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const i = parseInt(btn.getAttribute("data-index"), 10);
      deleteHistoryItem(i);
    });
  });
}

function deleteHistoryItem(index) {
  let history = [];
  try {
    history = JSON.parse(localStorage.getItem(HISTORY_KEY)) || [];
  } catch {
    history = [];
  }
  if (index >= 0 && index < history.length) {
    history.splice(index, 1);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
  }
  displayHistory();
}
